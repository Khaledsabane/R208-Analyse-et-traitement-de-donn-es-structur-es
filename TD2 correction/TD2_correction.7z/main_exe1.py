from Exe1 import *
"""
a=(input("Merci de donner la valeur de a "))
b=(input("Merci de donner la valeur de b "))

c= devise1(a,b)
"""


a=input("Merci de donner la valeur de a ")
b=input("Merci de donner la valeur de b ")

#while b == 0:
#    b = input("Merci de donner la valeur de b (!= 0) ")
c= devise3(a,b)